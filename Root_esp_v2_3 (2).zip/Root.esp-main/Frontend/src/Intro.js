import React,{useState} from 'react';
import {View,Text,Pressable,ScrollView} from 'react-native';
import {colors} from './theme';
import {kvSet} from './store';
import {Wordmark} from './ui';
const QUESTIONS=[
 ['Interior style',['Minimalist','Modern','Scandinavian','Classic','Industrial','Other']],
 ['Dominant home colors',['White / cream','Earth tones','Grey / black','Natural wood','Colorful','Other']],
 ['How many plants do you own?',['None yet','1–3','4–10','More than 10']],
 ['Types of plants',['Indoor foliage','Flowers','Succulents','Herbs','Mixed collection']],
 ['Electronic module preference',['Integrated in the pot','Attached separately','No preference']],
 ['What matters most?',['Automated care','Premium design','Both']]
];
export default function Intro({onDone}){
 const [step,setStep]=useState(-1);const [answers,setAnswers]=useState({});
 const finish=async()=>{try{await kvSet('rootesp.personalization.pending.v1',answers);}finally{onDone(null,true);}};
 const next=(option)=>{if(step>=0&&option)setAnswers(x=>({...x,[QUESTIONS[step][0]]:option}));if(step===QUESTIONS.length-1) {const final=option?{...answers,[QUESTIONS[step][0]]:option}:answers;kvSet('rootesp.personalization.pending.v1',final).finally(()=>onDone(null,true));}else setStep(i=>i+1);};
 return <ScrollView contentContainerStyle={{flexGrow:1,backgroundColor:colors.bg,justifyContent:'center',padding:30}}>
   <View style={{width:'100%',maxWidth:590,alignSelf:'center',gap:18}}>
     <Wordmark size={28}/><Text style={{fontSize:12,color:colors.muted,letterSpacing:2}}>TAKE YOUR LIFE SLOW.</Text>
     <Text style={{fontSize:36,color:colors.soil,fontWeight:'600',marginTop:34}}>{step<0?'Life can be stressful.':QUESTIONS[step][0]}</Text>
     <Text style={{color:colors.muted,fontSize:16,lineHeight:25}}>{step<0?'Let Root.esp handle everyday plant care, while you enjoy a thoughtfully designed space.':`Personalization · Question ${step+1} of ${QUESTIONS.length} · Optional`}</Text>
     {step>=0&&QUESTIONS[step][1].map(choice=><Pressable key={choice} onPress={()=>next(choice)} style={{backgroundColor:colors.paper,borderColor:colors.line,borderWidth:1,borderRadius:9,padding:17}}><Text style={{color:colors.soil}}>{choice}</Text></Pressable>)}
     {step<0&&<Pressable onPress={()=>setStep(0)} style={{backgroundColor:colors.fern,padding:17,borderRadius:8,alignItems:'center'}}><Text style={{color:colors.onFern,fontWeight:'700'}}>Get started</Text></Pressable>}
     <Pressable onPress={()=>{if(step<0)finish();else next(null);}} style={{padding:14,alignItems:'center'}}><Text style={{color:colors.muted}}>{step<0?'Skip personalization':'Skip this question'}</Text></Pressable>
   </View>
 </ScrollView>;
}
