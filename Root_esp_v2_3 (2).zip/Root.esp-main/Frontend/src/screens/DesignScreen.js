import React,{useEffect,useState} from 'react';
import {View,Text,TextInput,Pressable,Image,ActivityIndicator} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import {api,USE_MOCK} from '../api';
import {useAuth} from '../auth';
import {kvGet} from '../store';
import {getDesignHistory,saveDesignHistory,deleteDesignHistory,EXAMPLE_IMAGES} from '../designHistory';
import {Screen,Card,Btn,Sheet,Icon,IconBadge,Pill} from '../ui';
import {TourTarget} from '../tour';
import {colors,inputStyle} from '../theme';
const OPTIONS=['Matte ceramic','Glazed ceramic','3D-printed prototype'];
const ACCENT=()=>colors.section.design;
const imageFor=item=>item.imageType==='example-interior'?EXAMPLE_IMAGES[item.outcome]:item.imageType==='preset'?require('../../assets/design/example-2.png'):item.imageBase64?{uri:`data:${item.mimeType||'image/png'};base64,${item.imageBase64}`}:null;

function Placeholder({label}){
 return <View style={{width:'100%',aspectRatio:1.5,borderRadius:12,borderWidth:1.5,borderStyle:'dashed',borderColor:colors.line,backgroundColor:colors.mist,alignItems:'center',justifyContent:'center',gap:8}}>
  <Icon name="image-off-outline" size={32} color={colors.muted}/><Text style={{color:colors.muted}}>{label}</Text>
 </View>;
}
function Labelled({icon,label,color,children}){
 return <View style={{gap:8}}><View style={{flexDirection:'row',alignItems:'center',gap:6}}><Icon name={icon} size={16} color={color}/><Text style={{color,fontWeight:'700',fontSize:12,letterSpacing:1}}>{label.toUpperCase()}</Text></View>{children}</View>;
}

// Full view of one history entry: what the user uploaded and asked for, and what the designer returned.
function DesignDetail({item,onDelete,deleting,setDeleting}){
 const accent=ACCENT();
 const uploaded=item.uploaded?EXAMPLE_IMAGES[item.uploaded]:null;const outcome=imageFor(item);
 return <View style={{gap:16}}>
  <View style={{flexDirection:'row',gap:8,flexWrap:'wrap'}}>{item.example&&<Pill text="Demo example" tone="info" icon="star-outline"/>}{item.pending&&<Pill text="Images coming soon" tone="warn" icon="clock-outline"/>}<Pill text={item.mode==='interior'?'Interior design':'Pot design'} tone="muted" icon={item.mode==='interior'?'sofa-outline':'flower-pollen-outline'}/></View>
  {(item.example||uploaded)&&<Labelled icon="account-outline" label="Uploaded by user" color={colors.muted}>
   {uploaded?<Image source={uploaded} resizeMode="cover" style={{width:'100%',aspectRatio:1.5,borderRadius:12}}/>:<Placeholder label="User photo coming soon"/>}
   {!!item.prompt&&<View style={{alignSelf:'flex-end',maxWidth:'92%',backgroundColor:colors.fern,borderRadius:14,borderBottomRightRadius:4,padding:12}}><Text style={{color:colors.onFern,lineHeight:20}}>“{item.prompt}”</Text></View>}
  </Labelled>}
  <Labelled icon="palette-outline" label={item.example?'Outcome by designer':'Design outcome'} color={accent}>
   {outcome?<Image source={outcome} resizeMode="cover" style={{width:'100%',aspectRatio:1.5,borderRadius:12}}/>:<Placeholder label="Designer outcome coming soon"/>}
   <Text style={{color:colors.soil,lineHeight:22}}>{item.description}</Text>
  </Labelled>
  {item.designNotes?.length>0&&<View style={{gap:8}}><Text style={{fontWeight:'700',color:colors.soil,fontSize:16}}>Design choices</Text>{item.designNotes.map((n,i)=><View key={i} style={{flexDirection:'row',gap:8}}><Icon name="check" size={18} color={accent}/><Text style={{color:colors.soil,flex:1,lineHeight:20}}>{n}</Text></View>)}</View>}
  {item.plants?.length>0&&<View style={{gap:10}}>
   <Text style={{fontWeight:'700',color:colors.soil,fontSize:16}}>Plants in this design and their needs</Text>
   {item.plants.map((p,i)=><View key={p.latin} style={{backgroundColor:colors.mist,borderRadius:12,padding:14,gap:6}}>
    <View style={{flexDirection:'row',alignItems:'center',gap:10}}>
     <View style={{width:28,height:28,borderRadius:14,backgroundColor:colors.section.plants,alignItems:'center',justifyContent:'center'}}><Text style={{color:colors.isDark?'#10281B':'#FFFFFF',fontWeight:'700'}}>{i+1}</Text></View>
     <View style={{flex:1}}><Text style={{color:colors.soil,fontWeight:'700',fontSize:15}}>{p.en}{p.ro!==p.en?` — ${p.ro}`:''}</Text><Text style={{color:colors.muted,fontStyle:'italic'}}>{p.latin}</Text></View>
    </View>
    <Text style={{color:colors.soil,lineHeight:20}}>{p.role}</Text>
    <View style={{flexDirection:'row',gap:6,alignItems:'flex-start'}}><Icon name="water-outline" size={16} color={colors.info} style={{marginTop:2}}/><Text style={{color:colors.soil,flex:1,lineHeight:20}}><Text style={{fontWeight:'700'}}>Needs: </Text>{p.needs}</Text></View>
   </View>)}
  </View>}
  <Text style={{color:colors.muted,fontSize:12}}>Material: {item.material} · Size: {item.dimensions}</Text>
  {Object.keys(item.answers||{}).length>0&&<Text style={{color:colors.muted,fontSize:12}}>Saved answers: {Object.entries(item.answers).map(([k,v])=>`${k}: ${v}`).join(' · ')}</Text>}
  {!item.example&&(deleting?<View style={{flexDirection:'row',gap:12,alignItems:'center',flexWrap:'wrap'}}><Text style={{color:colors.soil}}>Delete this saved design?</Text><Btn small tone="danger" title="Delete" onPress={onDelete}/><Btn small outline title="Cancel" onPress={()=>setDeleting(false)}/></View>:<Btn small outline icon="delete-outline" title="Remove from history" onPress={()=>setDeleting(true)}/>)}
 </View>;
}

export default function DesignScreen(){
 const {user}=useAuth();const [deleting,setDeleting]=useState(false),[history,setHistory]=useState([]),[open,setOpen]=useState(null),[saving,setSaving]=useState(false);const [mode,setMode]=useState('interior'),[photo,setPhoto]=useState(null),[prefs,setPrefs]=useState({}),[description,setDescription]=useState(''),[material,setMaterial]=useState(OPTIONS[0]),[dimensions,setDimensions]=useState(''),[result,setResult]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[order,setOrder]=useState(null),[requests,setRequests]=useState([]);
 const accent=ACCENT();
 useEffect(()=>{kvGet(`rootesp.personalization.account.${USE_MOCK?'demo':'real'}.${user.UserID}`,null).then(async x=>setPrefs(x||{})).catch(()=>{});getDesignHistory(user).then(setHistory).catch(()=>{});if(!USE_MOCK)api.getDesignRequests().then(setRequests).catch(()=>{});},[user.UserID]);
 const pick=async()=>{try{const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();if(!permission.granted){setError('Photo permission denied.');return;}const res=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:false,quality:0.75,base64:true});if(res.canceled)return;const a=res.assets?.[0];if(!a?.base64)return setError('Could not read selected image.');if(a.base64.length>8*1024*1024)return setError('Please choose a smaller image (under 6 MB).');setPhoto({uri:a.uri,base64:a.base64,mimeType:a.base64.startsWith('iVBOR')?'image/png':'image/jpeg'});setResult(null);setError('');}catch(e){setError(e.message);}};
 const generate=async()=>{if(!photo)return setError('Select a room or plant photo first.');setBusy(true);setError('');setOrder(null);try{const r=await api.generateDesign({mode,imageBase64:photo.base64,mimeType:photo.mimeType,preferences:prefs,description,material,dimensions});setResult(r);}catch(e){setError(e.message);}finally{setBusy(false);}};
 const preset=()=>{setResult({preset:true,imageType:'preset',description:mode==='plant'?'Sculptural matte ceramic planter with integrated Root.esp module space.':'Neutral interior arrangement with two contemporary ceramic planters.',specifications:{material,dimensions:dimensions||'22 × 20 cm',workflow:mode}});setError('');};
 const save=async()=>{if(!result)return;setSaving(true);setError('');try{
  await saveDesignHistory(user,{title:result.preset?'Preset design':`AI ${mode} concept`,subtitle:mode==='interior'?'Interior visualization':'Plant & pot design',mode,material,dimensions:dimensions||'22 × 20 cm',description:result.description,prompt:description||null,answers:prefs,imageType:result.preset?'preset':'ai',imageBase64:result.imageBase64||null,mimeType:result.mimeType||'image/png'});setHistory(await getDesignHistory(user));
 }catch(e){setError(e.message);}finally{setSaving(false);}};
 const request=async()=>{if(!result?.designId)return;setBusy(true);setError('');try{const r=await api.requestManufacturing({designId:result.designId,mode,material,dimensions,notes:description,designImageBase64:result.imageBase64,designImageMimeType:result.mimeType,specifications:result.specifications||{}});setOrder(r);setRequests(old=>[{RequestID:r.requestId,Status:r.status,Material:material,Workflow:mode},...old]);}catch(e){setError(e.message);}finally{setBusy(false);}};
 const remove=async()=>{try{setHistory(await deleteDesignHistory(user,open.id));setOpen(null);setDeleting(false);}catch(e){setError(e.message);}};
 const step=(n,title,icon)=><View style={{flexDirection:'row',alignItems:'center',gap:10,marginBottom:10}}><View style={{width:28,height:28,borderRadius:14,backgroundColor:accent,alignItems:'center',justifyContent:'center'}}><Text style={{color:colors.isDark?'#1F1433':'#FFFFFF',fontWeight:'700'}}>{n}</Text></View><Text style={{fontWeight:'700',color:colors.soil,fontSize:16,flex:1}}>{title}</Text><Icon name={icon} size={20} color={accent}/></View>;
 return <Screen><View style={{flexDirection:'row',alignItems:'center',gap:12}}><IconBadge name="palette-outline" color={accent} size={44}/><View style={{flex:1}}><Text style={{fontSize:30,fontWeight:'700',color:colors.soil}}>Design studio</Text><Text style={{color:colors.muted}}>Personalized planters and interior concepts, powered by optional AI.</Text></View></View>
 <TourTarget id="design.history"><Card><View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:10}}><View style={{flexDirection:'row',alignItems:'center',gap:8}}><Icon name="history" size={20} color={accent}/><Text style={{fontWeight:'700',color:colors.soil,fontSize:18}}>Design history</Text></View><Text style={{color:colors.muted,fontSize:12}}>{history.length} item{history.length===1?'':'s'}</Text></View>
 <Text style={{color:colors.muted,marginTop:6,marginBottom:6}}>Your saved concepts plus two demo examples. Saved locally per account on this device.</Text>
 {history.map(item=>{const img=item.imageType==='example-interior'?EXAMPLE_IMAGES[item.outcome]:imageFor(item);return <Pressable key={item.id} accessibilityRole="button" accessibilityLabel={`Open ${item.title}`} onPress={()=>{setDeleting(false);setOpen(item);}} style={({pressed})=>[{flexDirection:'row',alignItems:'center',gap:12,paddingVertical:12,borderTopWidth:1,borderColor:colors.line},pressed&&{opacity:.7}]}>
  {img?<Image source={img} resizeMode="cover" style={{width:84,height:56,borderRadius:8}}/>:<View style={{width:84,height:56,borderRadius:8,backgroundColor:colors.mist,alignItems:'center',justifyContent:'center'}}><Icon name={item.mode==='interior'?'sofa-outline':'flower-pollen-outline'} size={24} color={accent}/></View>}
  <View style={{flex:1,gap:2}}><View style={{flexDirection:'row',alignItems:'center',gap:6,flexWrap:'wrap'}}><Text style={{fontWeight:'700',color:colors.soil}}>{item.title}</Text>{item.example&&<Text style={{fontSize:11,color:colors.info,fontWeight:'700'}}>EXAMPLE</Text>}</View><Text style={{color:colors.muted,fontSize:13}} numberOfLines={1}>{item.subtitle||item.description}</Text><Text style={{color:colors.muted,fontSize:11}}>{item.example?item.createdAt:new Date(item.createdAt).toLocaleString()}</Text></View>
  <Icon name="chevron-right" size={22} color={colors.muted}/>
 </Pressable>;})}
 </Card></TourTarget>
 <TourTarget id="design.workflow"><Card>{step(1,'Choose a design workflow','gesture-tap-button')}<View style={{flexDirection:'row',gap:8,flexWrap:'wrap'}}>{[['interior','Interior visualization','sofa-outline'],['plant','Plant & pot design','flower-pollen-outline']].map(([v,t,ic])=><Pressable key={v} accessibilityRole="button" accessibilityState={{selected:mode===v}} onPress={()=>{setMode(v);setResult(null);}} style={{flexDirection:'row',alignItems:'center',gap:8,padding:12,borderWidth:1.5,borderRadius:10,borderColor:mode===v?accent:colors.line,backgroundColor:mode===v?accent+'1A':colors.paper}}><Icon name={ic} size={18} color={mode===v?accent:colors.muted}/><Text style={{color:colors.soil,fontWeight:mode===v?'700':'400'}}>{t}</Text></Pressable>)}</View></Card></TourTarget>
 <TourTarget id="design.photo"><Card>{step(2,'Reference photo','camera-outline')}<Text style={{color:colors.muted,marginBottom:12}}>{mode==='interior'?'Upload an interior photo.':'Upload your existing plant.'} Photos are transmitted to the configured AI provider only when you choose Generate.</Text><Btn icon="image-plus" title="Choose photograph" outline tone="design" onPress={pick}/>{photo&&<Image source={{uri:photo.uri}} resizeMode="contain" style={{width:'100%',height:225,marginTop:14,borderRadius:7}}/>}</Card></TourTarget>
 <Card>{step(3,'Production preferences','tune-variant')}<Text style={{color:colors.muted}}>Material</Text><View style={{flexDirection:'row',flexWrap:'wrap',gap:8,marginVertical:8}}>{OPTIONS.map(t=><Pressable key={t} accessibilityRole="button" accessibilityState={{selected:material===t}} onPress={()=>setMaterial(t)} style={{borderWidth:1.5,borderRadius:8,padding:9,borderColor:material===t?accent:colors.line,backgroundColor:material===t?accent+'1A':'transparent'}}><Text style={{color:colors.soil}}>{t}</Text></Pressable>)}</View><TextInput value={dimensions} onChangeText={setDimensions} placeholder="Approximate dimensions (cm), optional" placeholderTextColor={colors.muted} style={[inputStyle,{marginTop:8}]}/><TextInput value={description} onChangeText={setDescription} placeholder="Describe the desired arrangement, shape or finish" multiline placeholderTextColor={colors.muted} style={[inputStyle,{marginTop:10,minHeight:74}]}/><Text style={{color:colors.muted,fontSize:12,marginVertical:12}}>Your onboarding preferences are applied when available. Suggested dimensions are not engineering-certified.</Text><Btn icon="shape-outline" title="Use preset design (offline)" outline disabled={busy} onPress={preset}/><View style={{height:9}}/><Btn icon="creation" tone="design" title={busy?'Generating…':'Generate visualization'} disabled={!photo||busy||USE_MOCK} onPress={generate}/>{USE_MOCK&&<Text style={{color:colors.muted,marginTop:10}}>Prototype: AI design is not connected yet. Open the examples in Design history to see what a finished design looks like.</Text>}</Card>
 {busy&&<ActivityIndicator color={accent} size="large"/>}{!!error&&<Card style={{borderColor:colors.danger}}><Text style={{color:colors.danger}}>{error}</Text></Card>}
 {result&&<Card><Text style={{fontSize:18,fontWeight:'700',color:colors.soil}}>{result.preset?'Preset concept · Offline':'Generated concept · AI visualization'}</Text><Text style={{color:colors.muted,marginVertical:8}}>This is a design proposal, not a validated production drawing.</Text>{result.preset&&<Image source={require('../../assets/design/example-2.png')} resizeMode="contain" style={{width:'100%',height:280,borderRadius:8}}/>}{result.imageBase64&&<Image source={{uri:`data:${result.mimeType||'image/png'};base64,${result.imageBase64}`}} resizeMode="contain" style={{width:'100%',height:320}}/>}<Text style={{color:colors.soil,marginVertical:10}}>{result.description}</Text><Text style={{color:colors.muted,marginBottom:12}}>Production requires verification of dimensions, drainage, water containment, electronics clearance and material durability by the manufacturer.</Text><Btn icon="content-save-outline" title={saving?'Saving…':'Save to design history'} disabled={saving} outline onPress={save}/>{!result.preset&&<View style={{marginTop:12}}><Btn icon="factory" title="Submit for manufacturing review" onPress={request} disabled={busy}/></View>}{result.preset&&<Text style={{color:colors.muted,fontSize:12,marginTop:8}}>Preset is illustrative only. Manufacturing review requires a real generated concept.</Text>}</Card>}
 {requests.length>0&&<Card><Text style={{fontWeight:'700',color:colors.soil,marginBottom:8}}>Manufacturing reviews</Text>{requests.map(x=><View key={x.RequestID} style={{paddingVertical:10,borderTopWidth:1,borderColor:colors.line}}><Text style={{color:colors.soil}}>Request #{x.RequestID} · {x.Material}</Text><Text style={{color:colors.muted}}>Status: {x.Status}</Text></View>)}</Card>}
 {order&&<Card><Text style={{color:colors.soil,fontWeight:'700'}}>Review request #{order.requestId} submitted</Text><Text style={{color:colors.muted}}>Status: {order.status}. A manufacturer must approve the design before production. No payment or automatic order has been placed.</Text></Card>}
 <Sheet visible={!!open} wide title={open?`${open.title}${open.subtitle?` · ${open.subtitle}`:''}`:''} onClose={()=>{setOpen(null);setDeleting(false);}}>{open&&<DesignDetail item={open} onDelete={remove} deleting={deleting} setDeleting={setDeleting}/>}</Sheet>
 </Screen>;
}
