import React,{useEffect,useState} from 'react';
import {Text,View,Pressable} from 'react-native';
import {useAuth} from '../auth';
import {usePrefs} from '../prefs';
import {api} from '../api';
import {Screen,Card,Btn,IconBadge,Icon} from '../ui';
import {TourTarget} from '../tour';
import {colors,THEMES} from '../theme';
import {replayAllTours} from '../tourControl';
const Row=({icon,color,title,body,children})=><Card style={{gap:12}}><View style={{flexDirection:'row',alignItems:'center',gap:12}}><IconBadge name={icon} color={color}/><View style={{flex:1}}><Text style={{fontWeight:'700',color:colors.soil,fontSize:16}}>{title}</Text>{!!body&&<Text style={{color:colors.muted}}>{body}</Text>}</View></View>{children}</Card>;
export default function MenuScreen({navigation}){
 const {user,accounts,switchAccount,signOut,openSettings,beginAddAccount,openKidsSetup}=useAuth();const prefs=usePrefs();const [tourMessage,setTourMessage]=useState('');const [kids,setKids]=useState([]);
 useEffect(()=>{api.getKidAccounts(user.UserID).then(setKids).catch(()=>setKids([]));},[user.UserID,accounts.length]);
 const kidSession=id=>accounts.find(a=>a.user.UserID===id);
 return <Screen>
 <View style={{flexDirection:'row',alignItems:'center',gap:12}}><IconBadge name="account-circle-outline" color={colors.section.profile} size={44}/><View><Text style={{fontSize:30,color:colors.soil,fontWeight:'700'}}>Profile</Text><Text style={{color:colors.muted}}>Account, hardware and preferences</Text></View></View>
 <Card style={{flexDirection:'row',alignItems:'center',gap:14}}><View style={{width:52,height:52,borderRadius:26,backgroundColor:colors.fern,alignItems:'center',justifyContent:'center'}}><Text style={{color:colors.onFern,fontSize:22,fontWeight:'700'}}>{(user.Username||'?')[0].toUpperCase()}</Text></View><View style={{flex:1}}><Text style={{fontSize:18,fontWeight:'700',color:colors.soil}}>{user.Username}</Text><Text style={{color:colors.muted}}>{user.Email}</Text></View></Card>
 <TourTarget id="profile.devices"><Row icon="chip" color={colors.info} title="Device management" body="Register, link or replace Root.esp hardware."><Btn icon="chip" title="View, register or replace devices" onPress={()=>navigation.navigate('Devices')}/></Row></TourTarget>
 <Row icon="bell-outline" color={colors.warning} title="Notifications" body="Watering, device and plant alerts."><Btn icon="bell-outline" title="Review alerts" outline onPress={()=>navigation.navigate('Alerts')}/></Row>
 <TourTarget id="profile.kids"><Row icon="account-child-outline" color={colors.section.plants} title="Kids accounts" body="Same email as yours, each with its own password. Kids get a colourful interface without Design or the AI chat.">
  {kids.map(k=><View key={k.UserID} style={{flexDirection:'row',alignItems:'center',gap:10,padding:10,borderRadius:10,backgroundColor:colors.mist}}><Icon name="face-man-shimmer-outline" size={22} color={colors.section.plants}/><Text style={{color:colors.soil,fontWeight:'600',flex:1}}>{k.DisplayName||k.Username}</Text>{kidSession(k.UserID)&&<Btn small outline title="Switch" onPress={()=>switchAccount(kidSession(k.UserID))}/>}</View>)}
  {kids.length===0&&<Text style={{color:colors.muted}}>No kids accounts yet.</Text>}
  <Btn icon="plus" title="Create a kids account" tone="plants" onPress={openKidsSetup}/>
 </Row></TourTarget>
 <TourTarget id="profile.appearance"><Row icon="palette-swatch-outline" color={colors.section.design} title="Appearance" body={`${THEMES[colors.themeId]?.label||'Forest'} theme · ${prefs.appearance==='system'?'follows system':prefs.appearance} mode`}>
  <View style={{flexDirection:'row',gap:6}}>{[colors.fern,colors.accent,colors.success,colors.warning,colors.danger,colors.info].map((c,i)=><View key={i} style={{width:22,height:22,borderRadius:11,backgroundColor:c,borderWidth:1,borderColor:colors.line}}/>)}</View>
  <Btn icon="palette-outline" title="Themes and appearance" outline onPress={()=>openSettings('appearance')}/>
 </Row></TourTarget>
 <TourTarget id="profile.tours"><Row icon="map-marker-path" color={colors.accent} title="Guided walkthroughs" body="Restart all page tutorials whenever you need them."><Btn icon="replay" title="Replay guided tours" outline onPress={()=>replayAllTours(user).then(()=>setTourMessage('Tours reset. The walkthrough starts on this page.')).catch(e=>setTourMessage(e.message))}/>{!!tourMessage&&<Text accessibilityRole="alert" style={{color:colors.muted}}>{tourMessage}</Text>}</Row></TourTarget>
 {user.IsAdmin&&<Btn icon="shield-account-outline" title="Administration" outline onPress={()=>navigation.navigate('Admin')}/>}
 {accounts.length>1&&<Card><Text style={{color:colors.soil,fontWeight:'700',marginBottom:10}}>Switch account</Text>{accounts.filter(x=>x.user.UserID!==user.UserID).map(x=><Pressable key={x.user.UserID} accessibilityRole="button" onPress={()=>switchAccount(x)} style={{padding:10,flexDirection:'row',alignItems:'center',gap:8}}><Icon name={x.user.IsKid?'account-child-outline':'account-outline'} size={20} color={colors.fern}/><Text style={{color:colors.fern}}>{x.user.IsKid?`${x.user.DisplayName} (kids)`:x.user.Username}</Text></Pressable>)}</Card>}
 <Btn icon="account-plus-outline" title="Add another account" outline onPress={beginAddAccount}/>
 <Btn icon="logout" title="Sign out" outline tone="muted" onPress={signOut}/>
 </Screen>;
}
