import React,{useCallback,useState} from 'react';
import {View,Text,Pressable} from 'react-native';
import {useLiveRefresh} from '../useLiveRefresh';
import {useAuth} from '../auth';
import {useData} from '../appdata';
import {api,USE_MOCK} from '../api';
import {colors,toneColor} from '../theme';
import {Screen,Card,Loading,LoadFailure,Btn,PlantCard,IconBadge,Icon} from '../ui';
import {TourTarget} from '../tour';
import {isOnline,soilStatus,displayReading,plantMood,greeting} from '../logic';
export const describePlant=p=>{const online=p.device?isOnline(p.device.LastSeenAt):null;const mood=plantMood(p.latest,p.settings,online);const soil=soilStatus(p.latest?.SoilMoisture,p.settings?.SoilMoistureThreshold);return {mood,soil:{tone:soil.tone,text:displayReading(p.latest?.SoilMoisture,'%',0,100),temp:displayReading(p.latest?.AirTemperature,'°C')}};};
const FRONT_PAGE_PLANTS=4;
export default function HomeScreen({navigation}){
 const {user}=useAuth();const {getLook}=useData();const [plants,setPlants]=useState(null),[err,setErr]=useState('');
 const load=useCallback((active=()=>true)=>{if(typeof active!=='function')active=()=>true;return api.getPlants(user.UserID).then(x=>{if(active()){setPlants(x);setErr('');}}).catch(e=>{if(active())setErr(e.message);});},[user.UserID]);useLiveRefresh(load);
 if(err)return <LoadFailure message={err} onRetry={load}/>;if(!plants)return <Loading/>;
 const connected=plants.filter(p=>p.device),offline=connected.filter(p=>!isOnline(p.device.LastSeenAt)),attention=plants.filter(p=>p.device&&describePlant(p).mood.tone!=='good');
 const stats=[['Plants',plants.length,'sprout',colors.section.plants],['Linked devices',connected.length,'chip',colors.info],['Offline devices',offline.length,'wifi-off',offline.length?colors.danger:colors.muted],['Check required',attention.length,'alert-circle-outline',attention.length?colors.warning:colors.success]];
 return <Screen>
 <View><Text style={{color:colors.muted,fontSize:13}}>{greeting().text}, {user.Username}</Text><Text style={{fontSize:30,color:colors.soil,fontWeight:'700'}}>Overview</Text><Text style={{color:colors.muted,marginBottom:6}}>Plant health and smart-device status · {USE_MOCK?'DEMO DATA':'Connected backend'}</Text></View>
 <TourTarget id="home.stats"><View style={{flexDirection:'row',flexWrap:'wrap',gap:12}}>{stats.map(([label,value,icon,tone])=><Card key={label} style={{minWidth:145,flexGrow:1,flexBasis:145,gap:8}}><View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Text style={{color:colors.muted,fontSize:12}}>{label}</Text><IconBadge name={icon} color={tone} size={30}/></View><Text style={{color:colors.soil,fontSize:32,fontWeight:'700'}}>{value}</Text></Card>)}</View></TourTarget>

 <TourTarget id="home.plants"><View style={{gap:12}}>
  <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginTop:12,gap:10,flexWrap:'wrap'}}>
   <View style={{flexDirection:'row',alignItems:'center',gap:10}}><IconBadge name="sprout" color={colors.section.plants} size={32}/><Text style={{fontSize:20,fontWeight:'700',color:colors.soil}}>My plants</Text></View>
   <View style={{flexDirection:'row',gap:8}}><Btn small outline icon="plus" title="Add" onPress={()=>navigation.navigate('AddPlant')}/>{plants.length>0&&<Btn small icon="arrow-right" title={plants.length>FRONT_PAGE_PLANTS?`See all ${plants.length}`:'Open'} onPress={()=>navigation.navigate('Plants')}/>}</View>
  </View>
  {plants.length===0?<Card style={{alignItems:'center',gap:10}}><Icon name="sprout-outline" size={34} color={colors.muted}/><Text style={{color:colors.muted,textAlign:'center'}}>No plants yet. Add your first plant to start monitoring it.</Text></Card>
   :<View style={{flexDirection:'row',flexWrap:'wrap',gap:12}}>{plants.slice(0,FRONT_PAGE_PLANTS).map(p=>{const d=describePlant(p);return <PlantCard key={p.PlantID} compact plant={p} look={getLook(p)} mood={d.mood} soil={d.soil} onPress={()=>navigation.navigate('PlantDetail',{plantId:p.PlantID})}/>;})}</View>}
 </View></TourTarget>

 <TourTarget id="home.attention"><View style={{gap:12}}>
 <View style={{flexDirection:'row',alignItems:'center',gap:10,marginTop:12}}><IconBadge name="alert-circle-outline" color={attention.length?colors.warning:colors.success} size={32}/><Text style={{fontSize:20,fontWeight:'700',color:colors.soil}}>Needs attention</Text></View>
 {!attention.length?<Card style={{flexDirection:'row',alignItems:'center',gap:10}}><Icon name="check-circle" size={22} color={colors.success}/><Text style={{color:colors.muted,flex:1}}>{connected.length?'No issues detected in the currently available measurements.':'Connect a Root.esp device to start live monitoring.'}</Text></Card>:attention.map(p=>{const m=describePlant(p).mood;return <Pressable key={p.PlantID} accessibilityRole="button" onPress={()=>navigation.navigate('PlantDetail',{plantId:p.PlantID})}><Card style={{borderLeftWidth:4,borderLeftColor:toneColor[m.tone]}}><Text style={{fontWeight:'700',color:colors.soil}}>{p.PlantName}</Text><Text style={{color:colors.muted}}>{m.label} · Soil moisture: {displayReading(p.latest?.SoilMoisture,'%',0,100)}</Text><Text style={{color:colors.muted,fontSize:12,marginTop:6}}>Sensor-based status, not an AI prediction. Open plant details for settings and actions.</Text></Card></Pressable>;})}
 </View></TourTarget>
 <TourTarget id="home.actions"><View style={{flexDirection:'row',gap:12,flexWrap:'wrap',marginTop:12}}><Btn icon="chip" title="Devices" outline onPress={()=>navigation.navigate('Devices')}/><Btn icon="bell-outline" title="Notifications" outline onPress={()=>navigation.navigate('Alerts')}/><Btn icon="robot-happy-outline" title="Ask the assistant" outline tone="info" onPress={()=>navigation.navigate('Assistant')}/></View></TourTarget>
 </Screen>;
}
