import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useLiveRefresh } from '../useLiveRefresh';
import { useAuth } from '../auth';
import { useData } from '../appdata';
import { api, USE_MOCK } from '../api';

import { colors, createStyles } from '../theme';
import { Card, Loading, LoadFailure, Btn, Screen, PlantCard, Icon } from '../ui';
import { TourTarget } from '../tour';
import { describePlant } from './HomeScreen';

export default function PlantsScreen({ navigation }) {
  const { user } = useAuth();
  const { getLook } = useData();
  const [plants, setPlants] = useState(null);
  const [loadError, setLoadError] = useState('');

  const load = useCallback((isActive = () => true) => {
    if (typeof isActive !== 'function') isActive = () => true;
    setLoadError('');
    return api.getPlants(user.UserID).then((data) => { if (isActive()) setPlants(data); }).catch((e) => { if (isActive()) setLoadError(e.message); });
  }, [user.UserID]);
  useLiveRefresh(load);


  if (loadError) return <LoadFailure message={loadError} onRetry={load} />;
  if (!plants) return <Loading />;

  return (
    <Screen>
      {USE_MOCK && <Text style={{color:colors.muted,fontSize:11,letterSpacing:1}}>DEMONSTRATION DATA · NOT LIVE SENSOR MEASUREMENTS</Text>}
      <View style={s.top}>
        <View style={{ flex: 1 }}>
          <Text style={s.h}>My plants</Text>
          <Text style={{ color: colors.muted }}>{plants.length} plant{plants.length === 1 ? '' : 's'}</Text>
        </View>
        <TourTarget id="plants.add"><Btn icon="plus" title="Add plant" onPress={() => navigation.navigate('AddPlant')} /></TourTarget>
      </View>
      {plants.length === 0 ? (
        <TourTarget id="plants.grid"><Card style={{ alignItems: 'center', gap: 12 }}>
          <Icon name="sprout-outline" size={36} color={colors.muted} />
          <Text style={{ color: colors.muted, textAlign: 'center' }}>Nothing here yet. Add as many plants as you like, and optionally link a smart device.</Text>
        </Card></TourTarget>
      ) : (
        <TourTarget id="plants.grid"><View style={s.grid}>
          {plants.map((p) => {
            const d = describePlant(p);
            return <PlantCard key={p.PlantID} plant={p} look={getLook(p)} mood={d.mood} soil={d.soil} onPress={() => navigation.navigate('PlantDetail', { plantId: p.PlantID })} />;
          })}
        </View></TourTarget>
      )}
    </Screen>
  );
}

const s = createStyles(() => ({
  top: { flexDirection: 'row', alignItems: 'center', gap: 12, flexWrap: 'wrap' },
  h: { fontSize: 26, fontWeight: '800', color: colors.soil },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
}));
