// One icon component for the whole app (Material Community Icons, bundled with Expo).
// Use this instead of emoji so the interface stays consistent on every platform.
import React from 'react';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from './theme';

export default function Icon({ name, size = 20, color, style }) {
  return <MaterialCommunityIcons name={name} size={size} color={color || colors.soil} style={style} />;
}
// True when a stored "look" value is an icon name rather than a legacy emoji.
export const isIconName = (v) => typeof v === 'string' && /^[a-z][a-z0-9-]*$/.test(v);
