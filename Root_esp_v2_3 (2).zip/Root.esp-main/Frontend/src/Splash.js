import React from 'react';
import {View,Text,ActivityIndicator} from 'react-native';
import {colors} from './theme';
import {Wordmark} from './ui';
export default function Splash(){return <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:colors.bg,gap:10}}><Wordmark size={38}/><Text style={{color:colors.muted,fontSize:12,letterSpacing:2}}>TAKE YOUR LIFE SLOW.</Text><ActivityIndicator color={colors.fern} style={{marginTop:20}}/></View>;}
