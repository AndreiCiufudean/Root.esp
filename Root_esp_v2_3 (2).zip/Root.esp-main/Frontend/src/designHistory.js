import {kvGet,kvSet} from './store';
import {USE_MOCK} from './api';
const key=user=>`rootesp.design.archive.v1.${USE_MOCK?'demo':'real'}.${user.UserID}`;

// ---- Built-in demo entries (prototype). They stay until the design API is connected. ----
export const EXAMPLE_IMAGES={
 roomUploaded:require('../assets/design/eg-room-uploaded.jpg'),
 roomDesigned:require('../assets/design/eg-room-designed.jpg'),
};

export const exampleDesign={
 id:'eg',example:true,title:'eg design',subtitle:'Living room greened for a Romanian climate',mode:'interior',
 material:'Matte ceramic planters, built-in window planter',dimensions:'Window planter approx. 180 × 35 × 40 cm',
 createdAt:'Example · demo design',imageType:'example-interior',
 prompt:'Recommend plants for the Romanian environment and design my room, knowing this is my room.',
 uploaded:'roomUploaded',outcome:'roomDesigned',
 description:'A warm, minimalist living room is layered with plants that suit Romanian homes: hardy herbs and flowering shrubs by the bright window, shade-tolerant foliage away from it, and trailing plants on the lit shelves. Root.esp irrigation lines and soil-moisture sensors are hidden inside the planters, so nothing technical is visible.',
 designNotes:[
  'The long planter under the window gets the most light, so it holds the sun-loving Mediterranean plants.',
  'Shade-tolerant foliage plants sit further into the room, where light is bright but indirect.',
  'Trailing plants soften the floating shelves and draw the eye upward.',
  'Drip lines and Root.esp sensors are built into each planter, with one discreet controller at the end of the window planter.',
 ],
 plants:[
  {en:'Hydrangea',ro:'Hortensie',latin:'Hydrangea macrophylla',role:'Large blue flower heads in the window planter give the room its main splash of colour.',needs:'Bright light with some protection from hot afternoon sun, and evenly moist, slightly acidic soil. Water generously in summer; never let the root ball dry out completely.'},
  {en:'Rosemary',ro:'Rozmarin',latin:'Salvia rosmarinus',role:'Fine, upright evergreen stems add texture and a fresh scent next to the lavender.',needs:'Full sun and gritty, fast-draining soil. Water only when the top layer is dry; it dislikes wet roots, especially in winter.'},
  {en:'Peace Lily',ro:'Spathiphyllum',latin:'Spathiphyllum wallisii',role:'White flowers and glossy leaves next to the window planter bridge the sunny and the shady parts of the room.',needs:'Medium, indirect light and evenly moist soil. It droops when thirsty and recovers quickly after watering; keep away from cold draughts.'},
  {en:'Monstera',ro:'Monstera',latin:'Monstera deliciosa',role:'Big split leaves beside the sofa act as a living sculpture.',needs:'Bright, indirect light and watering when the top 3–5 cm of soil are dry. Likes warmth (18–27 °C) and occasional leaf cleaning.'},
  {en:'Boston Fern',ro:'Ferigă',latin:'Nephrolepis exaltata',role:'Soft, arching fronds on the upper shelf add a lush, airy layer.',needs:'Indirect light, constantly slightly moist soil and higher humidity. Benefits from misting during winter heating season.'},
  {en:'Lavender',ro:'Lavandă',latin:'Lavandula angustifolia',role:'Purple flowering stems add color and a Mediterranean accent.',needs:'Full sun, very well-drained soil, and relatively dry conditions. Better outdoors or on a very sunny balcony.'},
  {en:'Olive Tree',ro:'Măslin',latin:'Olea europaea',role:'Used as the taller sculptural plant, with a woody trunk and slender silver-green leaves.',needs:'Strong direct sunlight, good drainage, and a cool, bright winter rest period. Not reliably winter-hardy outdoors in much of Romania.'},
  {en:'Golden Pothos',ro:'Epipremnum',latin:'Epipremnum aureum',role:'The trailing foliage on the floating shelves creates a natural cascading effect.',needs:'Medium to bright indirect light and watering when the top few centimeters of soil have dried.'},
  {en:'English Ivy',ro:'Iederă',latin:'Hedera helix',role:'Spills over the edge of the window planter and softens its outline.',needs:'Bright, indirect light and cool rooms. Keep soil lightly moist; native to Romania and very tolerant.'},
 ],
 answers:{'Interior style':'Minimalist','Dominant home colors':'White / cream','Types of plants':'Mixed collection','Electronic module preference':'Integrated in the pot','What matters most?':'Both'},
};

// Placeholder until the custom-pot example images are supplied.
export const examplePot={
 id:'eg-pot',example:true,pending:true,title:'eg pot custom',subtitle:'Custom planter design',mode:'plant',
 material:'Matte ceramic',dimensions:'To be confirmed',createdAt:'Example · images coming soon',imageType:'example-pot',
 prompt:'Design a custom pot for my plant that hides the Root.esp module.',
 description:'This example will show a photo uploaded by the user next to the custom pot created by the designer. The images are being prepared.',
 plants:[],designNotes:[],answers:{},
};
export const EXAMPLES=[exampleDesign,examplePot];
const isExample=r=>EXAMPLES.some(e=>e.id===r.id);

export async function getDesignHistory(user){const rows=await kvGet(key(user),[]);return [...EXAMPLES,...(Array.isArray(rows)?rows.filter(r=>!isExample(r)&&!r.example):[])];}
export async function saveDesignHistory(user,entry){const previous=await getDesignHistory(user);const next=[{...entry,id:`design-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,createdAt:new Date().toISOString()},...previous.filter(x=>!x.example)].slice(0,40);if(!await kvSet(key(user),next))throw new Error('Could not save design on this device.');return [...EXAMPLES,...next];}

// Examples remain permanently available; only user-created designs can be removed.
export async function deleteDesignHistory(user,id){
 if(EXAMPLES.some(e=>e.id===id))throw new Error('The built-in examples cannot be deleted.');
 const previous=await getDesignHistory(user);
 const own=previous.filter(item=>!item.example);
 const next=own.filter(item=>item.id!==id);
 if(next.length===own.length)throw new Error('Design not found.');
 if(!await kvSet(key(user),next))throw new Error('Could not delete this design on this device.');
 return [...EXAMPLES,...next];
}
